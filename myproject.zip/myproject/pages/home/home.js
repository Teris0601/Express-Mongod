// pages/home/home.js
var myRequest = require('../../utils/request.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    arr:[1,1,1,1,1],
    itemInfo:[],
    bimg:[],
    imgUrls:[
      '../img/h1.jpg',
      '../img/h2.jpg',
      '../img/h3.jpg',
    ],
    iname:'',
    pageNo:1,
    pageSize:2,
    reflag:true,
    scrollTop: 0,
    floorstatus: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getItemListInfo();
    this.getBannerListInfo() ;
  },
  getSearchName(e){
    name=e.detail.value;
    this.setData({
       iname:name
    })
  },
  getItemListInfo(){
    var dataUrl = app.globalData.antiqueBaseUrl + "topic.html";
    var pagesize = this.data.pageSize;
    var pageno = this.data.pageNo;
    var data = { pageNo: pageno};
    var method = 'POST';
    var that=this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        //console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        //console.log(res.data.length)
        for (var i = 0; i < res.data.length; i++) {
          //console.log(res.data[i].imgs);
          var a = res.data[i].imgs;
          for (let j = 0; j < res.data[i].imgs.length; j++) {
            res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
          }
        }
        //console.log(res.data)
        var a = that.data.itemInfo;
        //console.log(a)
        if(res.data.length>0){
          for(var i=0;i<res.data.length;i++){
            a.push(res.data[i]);
          }
          
          //console.log(a);
          that.setData({
            itemInfo: a,
            reflag:true
          })
        }else{
           that.setData({
              reflag:false
           })
        }
       
      })
      .catch(err => {
        //console.log(err)
      })
    
  },
  getBannerListInfo() {
    var dataUrl = app.globalData.antiqueBaseUrl + "slideShow.html";
    var data = {};
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
      
        //////console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        ////console.log(res.data.length)

        for (let j = 0; j < res.data.length; j++) {
          res.data[j].img = imgurl + res.data[j].img;
        }

        ////console.log(res.data);
        that.setData({
          bimg: res.data
        })
       
        
       
       
    })
      .catch(err => {
        ////console.log(err)
      })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },
  goSort(){
    wx.navigateTo({
      url: '../sort/sort',
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },
  goTopicDetail(e){
    ////console.log(e.target.data.info)
  },
  
  goDetail(e) {
    ////console.log(111122)
    var id = e.currentTarget.dataset.info;
    ////console.log(id);
    wx.navigateTo({
      url: '../detail/detail?id=' + id,
    })
  },
  goSearch(){
    var name = this.data.iname;
    wx.navigateTo({
      url: '../search/search?name='+name,
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
     
      
     
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  goTop: function (e) {
    this.setData({
      scrollTop: 0
    })
  },
  scroll: function (e) {
    ////console.log(e.detail.scrollTop)
    if (e.detail.scrollTop > 500) {
      this.setData({
        floorstatus: true
      });
    } else {
      this.setData({
        floorstatus: false
      });
    }
  },
  getMore(){
    var a = this.data.pageNo;
    if (this.data.reflag) {
      a++;
      ////console.log(a);
      this.setData({
        pageNo: a
      })
      this.getItemListInfo();
    } else {
      wx.showToast({
        title: '没有更多了',
      })
    }
  },
  //获取搜索信息
  getSearchInfo() {
    var dataUrl = app.globalData.antiqueBaseUrl + "topic.html";
    var content = this.data.name;
    var data = { content: name };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        ////console.log(res.data);
        ////console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        ////console.log(res.data.length)
        for (var i = 0; i < res.data.length; i++) {
          ////console.log(res.data[i].imgs);
          var a = res.data[i].imgs;
          for (let j = 0; j < res.data[i].imgs.length; j++) {
            res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
          }
        }
        ////console.log(res.data)
       
         
          that.setData({
            itemInfo: res.data,
          })
      })
      .catch(err => {
        ////console.log(err)
      })
  },
})