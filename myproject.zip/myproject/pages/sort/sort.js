// pages/sort/sort.js
var myRequest = require('../../utils/request.js');
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
      name:'',
      sid:0,
      itemInfo:[],
      pageNo: 1,
      pageSize: 2,
      reflag:true,
      itemList:[
        {
          id:1,
          name:'云翠珠宝'
        },
        {
          id: 2,
          name: '紫砂陶器'
        },
        {
          id: 3,
          name: '书画篆刻'
        },
        {
          id: 4,
          name: '古币银元'
        },
        {
          id: 5,
          name: '文玩杂项'
        },
        {
          id: 6,
          name: '茶酒木艺'
        },
        {
          id: 7,
          name: '铜器铁器'
        },
        {
          id: 8,
          name: '硬币纸品'
        },
      ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getInitItemInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  getInitItemInfo(){
    console.log(myRequest)
    var that=this;
    var dataUrl = app.globalData.antiqueBaseUrl + "topic.html";
    console.log(dataUrl);
    var id = wx.getStorageSync('openid');
    
    var data = { typeId: 1};
    var method = 'POST';
    myRequest.requestApi(dataUrl, method, data)
    .then(res => {
       console.log(res.data);
       var imgurl = app.globalData.antiqueImgUrl;
       console.log(res.data.length)
       for (var i = 0; i < res.data.length;i++){
         console.log(res.data[i].imgs);
         var a = res.data[i].imgs;
         for(let j=0;j<res.data[i].imgs.length;j++){
           res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
       }
       }
       console.log(res.data)
       that.setData({
           itemInfo:res.data
       })
        })
    .catch(err => {
       console.log(err)
        })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },
  getSortContent(e){
    console.log(e);
    var index=e.target.dataset.info;
    var id = this.data.itemList[index].id;
    var dataUrl = app.globalData.antiqueBaseUrl + "topic.html";
    var data = { typeId: id};
     
    var method = 'POST';
    var that=this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        console.log(res.data.length)
        for (var i = 0; i < res.data.length; i++) {
          console.log(res.data[i].imgs);
          var a = res.data[i].imgs;
          for (let j = 0; j < res.data[i].imgs.length; j++) {
            res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
          }
        }
        console.log(res.data)
        that.setData({
          itemInfo: res.data,
          tid: id
        })
      })
      .catch(err => {
        console.log(err)
      })
    this.setData({
       sid:index
    })
  },
  goDetail(e){
     console.log(e);
     var id=e.currentTarget.dataset.info;
     wx.navigateTo({
       url: '../detail/detail?id='+id,
     })
  },


  getItemListInfo() {
    var dataUrl = app.globalData.antiqueBaseUrl + "topic.html";
    var pagesize = this.data.pageSize;
    var pageno = this.data.pageNo;
    var tid=this.data.tid;
    var data = { pageNo: pageno,typeId:tid };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        console.log(res.data.length)
        for (var i = 0; i < res.data.length; i++) {
          console.log(res.data[i].imgs);
          var a = res.data[i].imgs;
          for (let j = 0; j < res.data[i].imgs.length; j++) {
            res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
          }
        }
        console.log(res.data)
        var a = that.data.itemInfo;
        console.log(a)
        if (res.data.length > 0) {
          for (var i = 0; i < res.data.length; i++) {
            a.push(res.data[i]);
          }

          console.log(a);
          that.setData({
            itemInfo: a,
            reflag: true
          })
        } else {
          that.setData({
            reflag: false
          })
        }

      })
      .catch(err => {
        console.log(err)
      })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  goTop: function (e) {
    this.setData({
      scrollTop: 0
    })
  },
  scroll: function (e) {
    console.log(e.detail.scrollTop)
    if (e.detail.scrollTop > 500) {
      this.setData({
        floorstatus: true
      });
    } else {
      this.setData({
        floorstatus: false
      });
    }
  },
  getMore() {
    var a = this.data.pageNo;
    if (this.data.reflag) {
      a++;
      console.log(a);
      this.setData({
        pageNo: a
      })
      this.getItemListInfo();
    } else {
      wx.showToast({
        title: '没有更多了',
      })
    }
  },
})