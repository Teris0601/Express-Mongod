var app = getApp();
var myRequest = require('../../utils/request.js');
var upload = require('../../utils/upload.js');
let animationShowHeight = 300;

Page({
  data: {
    pics: [],
    animationData: "",
    showModalStatus: false,
    imageHeight: 0,
    imageWidth: 0,
    sortname:'',
    resname:'',
    money:5.0,
    freeStatus:'',
    sflag:false,
    spflag:false,
    formid:'',
    prepayid:'',
    content:'',
    paymethod:'',
    loadHide:true,
    dectxt:[
      {
        desc: '1.每次鉴定只允许提交意见藏品的图片，最少上传两张图片'
      },
      {
        desc: '2.纸币需上传正反两面图片及透光图片'
      },
      {
        desc: '3.银元、古钱币、邮票需上传正反两面图片及边齿图片。'
      },
      {
        desc: '4.请上传藏品的多角度高清图片，方便专家更加精准的鉴定。'
      },
      {
        desc: '5.重复上传，单次上传多个藏品图片，转载图片，模糊图片等，不予鉴定。'
      },
      {
        desc: '6.因上传图片质量或单次多个藏品图片等问题造成的无法鉴定，不退还鉴定费。'
      },
      {
        isFocus: true,
        desc: '7.由于鉴定为远程图片鉴定，鉴定结果不作为交易依据。'
      },
      {
        desc: '8.以上内容最终解释权归邮币财富所有。'
      }
    ]
  },
  imageLoad: function (e) {
    this.setData({ imageHeight: e.detail.height, imageWidth: e.detail.width });
  },
  getcontent(e){
      this.setData({
        content:e.detail.value
      })
  },
  showModal: function () {
    // 显示遮罩层  
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(animationShowHeight).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  hideModal: function () {
    // 隐藏遮罩层  
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation;
    animation.translateY(animationShowHeight).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
  onShow: function () {
    this.getPublishInfo();
    if (wx.getStorageSync('sortname')){
      var sortnames = wx.getStorageSync('sortname');

      this.setData({
        sortname: sortnames
      })
    }
    if (wx.getStorageSync('resname')) {
      var resnames = wx.getStorageSync('resname');

      this.setData({
        resname: resnames
      })
    }
    if (wx.getStorageSync('spflag') || wx.getStorageSync('spflag')==false) {
      var spflag = wx.getStorageSync('spflag');
      console.log(spflag)
      this.setData({
        sflag: spflag
      })
    }
    let that = this;
    wx.getSystemInfo({
      success: function (res) {
        animationShowHeight = res.windowHeight;
      }
    })
  },
  //选择分类
  goCsort(){
    wx.navigateTo({
      url: '../choose/csort/csort',
    })
  },
  //选择需求
  goCrequest(){
    wx.navigateTo({
      url: '../choose/crequest/crequest',
    })
  },
  //获取免费发布资格
  getPublishInfo(){
    var dataUrl = app.globalData.antiqueBaseUrl + "/queryFreeStatus.html";
    var id=wx.getStorageSync('openid')
    var data = { openId:id };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        that.setData({
            freeStatus:res.data
        })
      })
      .catch(err => {
        console.log(err)
      })
  },
  //选取图片
  chooseImgs: function () {//这里是选取图片的方法
    var that = this;
    wx.chooseImage({
      count: 9 - this.data.pics.length, // 最多可以选择的图片张数，默认9
      sizeType: ['original', 'compressed'], // original 原图，compressed 压缩图，默认二者都有
      sourceType: ['album', 'camera'], // album 从相册选图，camera 使用相机，默认二者都有
      success: function (res) {
        var imgsrc = res.tempFilePaths;
        console.log(res)
        that.setData({
          pics: imgsrc
        });
        that.uploadimg();
        that.setData({
            loadHide:false,
        })
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })

  },
  //表单提交
  formSubmit:function(e){
    var isLogin=wx.getStorageSync("isLogin");
    if (isLogin){
    console.log(e)
    var val=e.detail.value;
    var formid=e.detail.formId;
   
    for(let i in val){
      console.log(i);
      console.log(val[i]);
      if (!val[i] || val[i]=="请选择") {
        wx.showModal({
          title: '消息提示',
          content: '您发布的信息有误。',
        })
        return false;
      } 
       
    }
    console.log('执行我了')
    this.showModal();
    this.setData({
       formid:formid,
    })
    }else{
       wx.showModal({
         title: '消息提示',
         content: '您还未登录',
         success:res=>{
            console.log(res)
            if(res.confirm){
                wx.switchTab({
                  url: '../application/application',
                })
            }
         }
       })
    }
  },
  uploadimg: function () {//这里触发图片上传的方法
    var pics = this.data.pics;
    var that=this;
    console.log(pics);
    upload.uploadimg({
      url: app.globalData.antiqueBaseUrl+'Wx_upload.html',//这里是你图片上传的接口
      path: pics//这里是选取的图片的地址数组
    }).then(res=>{
        console.log(res);
        
        that.setData({loadHide:true,})
      }).catch(err=>{
        console.log(err)
        that.setData({loadHide:true})
        })
    
  },
  //支付
  wxPayMent(e){
    console.log(e.target.dataset.pay);
    var pay = e.target.dataset.pay;
    this.setData({
       paymethod:pay,
    })
    if(pay==1){
    var dataUrl = app.globalData.antiqueBaseUrl + "prepay.html";
    var oid=wx.getStorageSync('openid');
    var data = { money: 5, openId: oid};
    var method = 'POST';
  
    var that = this;
      myRequest.requestApi(dataUrl, method, data)
        .then(res => {
          console.log(res.data);
          if(res.data.result){
            var a = res.data;
            var b = a.package;
            var c=b.split('=');
            that.setData({
               prepayid:c[1]
            })
            console.log(c);
            wx.requestPayment({
              'timeStamp': a.timeStamp,
              'nonceStr': a.nonceStr,
              'package': a.package,
              'signType': 'MD5',
              'paySign': a.paySign,
              'success': function (res) {
                  console.log(res)
                  that.publishMyItem();
              },
              'fail': function (res) {
              }
            })
          }else{
             wx.showModal({
               title: '消息提示',
               content: '支付失败',
             })
          }
         
        })
        .catch(err => {
          console.log(err)
        })
    }else{
      this.publishMyItem();
    } 
    
  },
  //发布
  freePublishItem(){
   
  },
  //用户发布商品
  publishMyItem(){
    var dataUrl = app.globalData.antiqueBaseUrl + "addtopic.html";
    var imgurls = app.globalData.imgs;
    var paymethod=this.data.paymethod;
    var nimg = [];
    for (var i = 0; i < imgurls.length; i++) {
      console.log(JSON.parse(imgurls[i]).path)
      nimg.push(JSON.parse(imgurls[i]).path)
    }
   
    var oid = wx.getStorageSync('openid');
    var tid=wx.getStorageSync('sortname').id;
    var need=wx.getStorageSync('resname').id;
    var content=this.data.content;
    var formid=this.data.formid;
    var strimg=nimg.join();
    var prepayid = this.data.prepayid ? this.data.prepayid:'0'; 
    var data = { imgUrls: strimg, userId: oid, typeId: tid, content: content, need: need, prepayId: prepayid, formId: formid, payMethod:paymethod};
    var method = 'POST';
    var that = this;
    
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        that.hideModal();
        var mtel=wx.getStorageSync('mtelnumber');
        if(!mtel){
          wx.showModal({
            title: '消息提示',
            content: '请绑定手机号',
            success: function(res){
                  console.log(res);
                  if(res.confirm){
                      wx.navigateTo({
                        url: '../applications/myupdatetel/myupdatetel',
                      })
                  }
            },
            fail: function (res) {

            }
          })
        }
      })
      .catch(err => {
        console.log(err)
      })
  },
  setCheck(){
     this.setData({
        spflag:!this.data.spflag
     })
  },
  setNextShow(){
      var spflag=this.data.spflag;
      wx.setStorageSync('spflag', spflag)
      this.setData({
         sflag:true,
      })
  }
})  
