var app = getApp();
var myRequest = require('../../utils/request.js');

let animationShowHeight = 300;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgs: ['../img/default_head.jpeg', '../img/default_head.jpeg', '../img/default_head.jpeg', '../img/default_head.jpeg', '../img/default_head.jpeg',],
    tid:'',
    ucon:'',
    iflag:true,
    zflag:true,
    animationData: "",
    showModalStatus: false,
    imageHeight: 0,
    imageWidth: 0,
    tel:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
     var id=options.id;
     this.setData({
       tid:id
     })
     this.getTopicDetailInfo(id)
     this.getLoginInfo();
  },
  imageLoad: function (e) {
    this.setData({ imageHeight: e.detail.height, imageWidth: e.detail.width });
  },
  showModal: function () {
    // 显示遮罩层  
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(animationShowHeight).step()
    animation.opacity(0).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      //animation.translateY(0).step()
      animation.opacity(1).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  hideModal: function () {
    // 隐藏遮罩层  
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation;
    //animation.translateY(animationShowHeight).step()
    animation.opacity(0).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      //animation.translateY(0).step()
      animation.opacity(1).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this;
    wx.getSystemInfo({
      success: function (res) {
        animationShowHeight = res.windowHeight;
      }
    })
  },
  getLoginInfo(){
     var isLogin=wx.getStorageSync('isLogin');
     if(!isLogin){
       wx.showModal({
         title: '消息提示',
         content: '您还未登录',
         success: res => {
           console.log(res)
           if (res.confirm) {
             wx.switchTab({
               url: '../application/application',
             })
           }
         }
       })
     }
  },
  //图片展示
  findImgsInfo(e){
     console.log(e);
     var that=this;
     var src=e.target.dataset.src;
     wx.previewImage({
       current: src,
       urls: that.data.detailInfo.imgs,
     })
  },
  //获取详情页信息
  getTopicDetailInfo(id){
    var dataUrl = app.globalData.antiqueBaseUrl + "/topicDetails.html";
    var data = { topicId: id };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        console.log(res.data.length)
        
          for (let j = 0; j < res.data.imgs.length; j++) {
            res.data.imgs[j] = imgurl + res.data.imgs[j];
          }
       
        console.log(res.data);
        that.setData({
           detailInfo:res.data
        })
      })
      .catch(err => {
        console.log(err)
      })
  },
  //获取用户输入信息
  getUserContent(e){
    console.log(e.detail.value);
    if (e.detail.value && e.detail.value!=null){
      this.setData({
        ucon: e.detail.value,
        iflag:false
      })
    }else{1
      this.setData({
        iflag: true
      })
    }
    
  },
  //发送评论
  sendRateWord(){
    var dataUrl = app.globalData.antiqueBaseUrl + "addTopicComment.html";
    var uid=wx.getStorageSync('openid');
    var tid=this.data.tid;
    var data = { userId: uid,topicId:tid,content:this.data.ucon };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        that.setData({
          ucon: '',
          iflag: true
        })
        that.getTopicDetailInfo(tid);
      })
      .catch(err => {
        console.log(err)
      })
  },
  //点赞
  goPrize(){
    var dataUrl = app.globalData.antiqueBaseUrl + "addLike.html ";
    var tid = this.data.tid;
    var data = {topicId: tid};
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        that.setData({
          zflag:false
        })
        that.getTopicDetailInfo(tid);
      })
      .catch(err => {
        console.log(err)
      })
  },
  //获取手机号码
  getContactTelphone(e){
     var tel=e.detail.value;
    
     this.setData({
         tel:tel
     })
  },
  //联系他
  msContact(){
    var ms = /^1[3456789]\d{9}$/; 
    
    var tel=this.data.tel;
    console.log(tel)
    var that=this;
    console.log(ms.test(tel));
    
    if(ms.test(tel)){
      var dataUrl = app.globalData.antiqueBaseUrl + "addContact.html";
      var uid=wx.getStorageSync('openid')
      var tid = this.data.tid;
      var oid = this.data.detailInfo.userId;
      var data = { activesOpenid:uid,passiveOpenid:oid,topicId: tid ,resPhone:tel};
      var method = 'POST';
      var that = this;
      if (uid!=oid){
        myRequest.requestApi(dataUrl, method, data)
          .then(res => {
            console.log(res.data);
            that.hideModal();

          })
          .catch(err => {
            console.log(err)
          })
      }else{
         wx.showModal({
           title: '消息提示',
           content: '不能联系自己',
         })
      }
      } else {
        //this.hideModal();
        wx.showModal({
          title: '消息提示',
          content: '手机号码输入错误',
        })
      }
    
      
    
  },
  //分享测眼力
  goShareInfo() {
    var dataUrl = app.globalData.antiqueBaseUrl + "topicImgsById.html";
    var tid = this.data.tid;
    var data = { topicId: tid };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        
        that.getTopicDetailInfo(tid);
      })
      .catch(err => {
        console.log(err)
      })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  returnHome(){
     wx.switchTab({
       url: '../home/home',
     })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    var that=this;
    var tid = this.data.tid;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '测眼力',
      path: '/pages/applications/myshare/myshare?tid='+tid,
      success: function (res) {
          wx.showToast({
            title: '转发成功',
          })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败", res);
      }
    }
  }
})