// pages/application/application.js
var app = getApp();
var myRequest = require('../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(app.globalData.userInfo)
    this.setData({
      userInfo: app.globalData.userInfo
    })
  },
  //去我的发布页面
  goMyOwnPublish(){
     wx.navigateTo({
       url: '../applications/mypublic/mypublic',
     })
  },
  //去修改手机号页面
  goMyUpdateTel(){
    wx.navigateTo({
      url: '../applications/myupdatetel/myupdatetel',
    })
  },
  getUserInfo(e){
    console.log(e);
    if (e.detail.userInfo)

      wx.login({
        success: function (res) {
          var code = res.code
          console.log(code);
          wx.setStorageSync('code', code)
          wx.request({
            url: app.globalData.antiqueBaseUrl + '/getOpenId.html',
            method: 'POST',
            header: {
              'content-type': 'application/x-www-form-urlencoded'
            },
            data: {
              code: res.code
            },
            success: function (res) {
              wx.setStorageSync('openid', res.data);
              console.log("openid: ", res.data);
              wx.setStorageSync('isLogin', true)
            }
          });
        }
      });
    
    
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo:e.detail.userInfo,
    })
    var a = e.detail.userInfo.nickName;
    var dataUrl = app.globalData.antiqueBaseUrl + "addUser.html";
    var oid = wx.getStorageSync('openid')
    var data = { openId: oid, name: e.detail.userInfo.nickName , headImg: e.detail.userInfo.avatarUrl};
    var method = 'POST';
    var that = this;

    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
      })
      .catch(err => {
        console.log(err)
      })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})