// pages/mine/authorizephone/authorizephone.js
var timers;
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    txt: '获取验证码',
    telnumber: '',
    flag: true,
    cflag:true,
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  myTelphone(e) {
    var tel = e.detail.value;
    console.log(tel);
    this.setData({
      telnumber: tel,
    })
  },
  receiveCode: function () {
    var ajaxPath = app.globalData.antiqueBaseUrl;
    var openid = wx.getStorageSync('openid');
    console.log(openid);
    console.log(ajaxPath);
    
    var ms = /^1[3456789]\d{9}$/;
    var i = 60;
    var that = this;
    if (ms.test(this.data.telnumber)) {
      
      this.setData({
        flag: false,
        cflag:false
      })
      clearInterval(timers);
      timers = setInterval(function () {
        if (i > 0) {
          i--;
          that.setData({
            txt: i + 's'
          })
        } else {
          clearInterval(timers);
          that.setData({
            txt: '重新获取',
            flag: true,
          })
        }
      }, 1000)

     
    } else {
      wx.showModal({
        title: '消息提示',
        content: '电话号码输入错误',
      })
    }
  },
  confirmBind: function () {
    var that = this;
    var ajaxPath = app.globalData.antiqueBaseUrl;
    var oid=wx.getStorageSync('openid')
    wx.request({
      url: ajaxPath + 'updateWechatPhone.html', //仅为示例，并非真实的接口地址
      method:'POST',
      data: {
        phone: that.data.telnumber,
        openID:oid
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.showToast({
          title: '修改成功',
          duration:2000,
          success:res=>{
            console.log(res);
            wx.setStorageSync('mtelnumber', that.data.telnumber);
            wx.switchTab({
              url: '../../home/home',
            })
          },
          fail:res=>{

          }
        })
        
      }
    })
  },

  onShareAppMessage: function () {

  }
})