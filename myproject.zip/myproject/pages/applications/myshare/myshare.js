// pages/applications/myshare/myshare.js
var app = getApp();
var myRequest = require('../../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      '../../img/h1.jpg',
      '../../img/h2.jpg',
      '../../img/h3.jpg',
    ],
    tid:'',
    sflag:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.judgeUserLogin();
       var tid=options.tid;
       this.setData({
         tid:tid
       })
       this.goShareInfo();
       
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      
  },
  //获取用户授权
  judgeUserLogin(){
      if(wx.getStorageSync('openid')){
          
      }else{
        var dataUrl = app.globalData.antiqueBaseUrl + "getOpenId.html";
        wx.login({
          success: function (res) {
            var code = res.code
            console.log(code);
            wx.setStorageSync('code', code)
            wx.request({
              url: dataUrl,
              method: 'POST',
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              data: {
                code: res.code
              },
              success: function (res) {
                wx.setStorageSync('openid', res.data);
                console.log("openid: ", res.data);
              }
            });
          }
        });
        wx.getSetting({
          success: res => {
            if (res.authSetting['scope.userInfo']) {
           
              wx.getUserInfo({
                success: res => {
                
                  app.globalData.userInfo = res.userInfo

                 
                  if (this.userInfoReadyCallback) {
                    this.userInfoReadyCallback(res)
                  }
                }
              })
            }
          }
        })
      }
  },
  //获取分享过来的信息
  goShareInfo() {
    var dataUrl = app.globalData.antiqueBaseUrl + "topicImgsById.html";
    var tid = this.data.tid;
    var data = { topicId: tid };
    var method = 'POST';
    var that = this;
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        var imgurl = app.globalData.antiqueImgUrl;
        

        for (let j = 0; j < res.data.imgUrls.length; j++) {
          res.data.imgUrls[j] = imgurl + res.data.imgUrls[j];
        }

        console.log(res.data);
        that.setData({
            itemInfo:res.data
        })
        
      })
      .catch(err => {
        console.log(err)
      })
  },
  //用户看真看假
  judgeUserTopic(e){
    if(this.data.sflag){
      wx.showModal({
        title: '消息提示',
        content: '您已经看过了',
      })
    }else{
      var num = e.target.dataset.jdg;
      var dataUrl = app.globalData.antiqueBaseUrl + "queryTFnum.html ";
      var tid = this.data.itemInfo.topicId;
      var data = { topicId: tid, num: num };
      var method = 'POST';
      var that = this;
      myRequest.requestApi(dataUrl, method, data)
        .then(res => {
          console.log(res.data);
          that.setData({
             sflag:true
          })
        })
        .catch(err => {
          console.log(err)
        })
    }
    
  }, 
  //查看专家评语
  findExpertWord(){
      var tid=this.data.tid;
      wx.redirectTo({
        url: '../../detail/detail?id=' + tid,
      })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  getLoginInfo(){
    
  }
})