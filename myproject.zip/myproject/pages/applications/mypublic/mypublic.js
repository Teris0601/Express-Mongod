var app = getApp(); 
var myRequest = require('../../../utils/request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgIndex:'',
    userinfo:{},
    sflag:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var userinfo = app.globalData.userInfo;
    this.setData({
      userinfo: userinfo
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMyPublishItem();
  },
  goDetails(e){
    
    var id = e.currentTarget.dataset.id;
    console.log(id);
    wx.navigateTo({
      url: '../../detail/detail?id=' + id,
    })

  },
  getImgs(e){
      var index=e.target.dataset.info;
      console.log(index);
      this.setData({
         imgIndex:index,
      })
  },
  findImgsInfo(e) {
    var src = e.currentTarget.dataset.src;
    console.log(this.data.myPublishInfo);
    var that = this;
    wx.previewImage({
      current: that.data.myPublishInfo[src].imgs[0],
      urls: that.data.myPublishInfo[src].imgs,
    })
  },
  getMyPublishItem(){
    var that=this;
    var openid=wx.getStorageSync('openid');
    var dataUrl = app.globalData.antiqueBaseUrl + "queryTopicByOpenId.html";
    var data = { openId: openid};
    var method = 'POST';
    myRequest.requestApi(dataUrl, method, data)
      .then(res => {
        console.log(res.data);
        var imgurl = app.globalData.antiqueImgUrl;
        console.log(res.data.length)
        for (var i = 0; i < res.data.length; i++) {
          console.log(res.data[i].imgs);
          var a = res.data[i].imgs;
          for (let j = 0; j < res.data[i].imgs.length; j++) {
            res.data[i].imgs[j] = imgurl + res.data[i].imgs[j];
          }
        }
          that.setData({
             myPublishInfo:res.data
          })
      })
      .catch(err => {
        console.log(err)
      })
   
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})