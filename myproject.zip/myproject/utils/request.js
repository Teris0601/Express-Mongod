function requestApi(url, method, datas) {
  console.log(datas)
  var promise = new Promise((resolve, reject) => {
    wx.request({
      url: url, 
      data: datas,
      method: method,
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        resolve(res)
      },
      fail: function (err) {
        reject(err)
      }
    })
  })
  return promise;
}

module.exports = {
  requestApi: requestApi
}