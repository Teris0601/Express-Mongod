//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    var _this=this;
    // 登录
    var openId = wx.getStorageSync('openid');
    //var openId=1;
  /*
    if (openId) {
      wx.getUserInfo({
        success: function (res) {
          wx.setStorageSync('userinfo', {
            nickName: res.userInfo.nickName,
            avatarUrl: res.userInfo.avatarUrl,
          })
          that.setData({
            nickName: res.userInfo.nickName,
            avatarUrl: res.userInfo.avatarUrl,
          })
        },
        fail: function () {
          // fail
          console.log("获取失败！")
        },
        complete: function () {
          // complete
          console.log("获取用户信息完成！")
        }
      })
    } else {
      console.log('获取信息中');
      wx.login({
        success: function (res) {
          console.log(res.code)
          console.log(_this.globalData.antiqueBaseUrl);
          if (res.code) {
            wx.getUserInfo({
              withCredentials: true,
              success: function (res_user) {
                wx.request({
                  //后台接口地址
                  url: _this.globalData.antiqueBaseUrl+'/getOpenId.html',
                  data: {
                    code: res.code,
                  },
                  method: 'POST',
                  header: {
                    'content-type': 'application /x-www-form-urlencoded'
                  },
                  success: function (res) {
                    console.log(res.data);
                    wx.setStorageSync('userinfo', {
                      nickName: res.userInfo.nickName,
                      avatarUrl: res.userInfo.avatarUrl,
                    })
                    that.setData({
                      nickName: res.data.nickName,
                      avatarUrl: res.data.avatarUrl,
                    })
                    wx.setStorageSync('openid', res.data.openId);

                  }
                })
              }, fail: function () {
                wx.showModal({
                  title: '警告通知',
                  content: '您点击了拒绝授权,将无法正常显示个人信息,点击确定重新获取授权。',
                  success: function (res) {
                     console.log(res)
                    if (res.confirm) {
                      wx.openSetting({
                        success: (res) => {
                          console.log(res)
                          if (res.authSetting["scope.userInfo"]) {////如果用户重新同意了授权登录
                            wx.login({
                              success: function (res_login) {
                                console.log(res_login.code);
                                if (res_login.code) {
                                  wx.getUserInfo({
                                    withCredentials: true,
                                    success: function (res_user) {
                                      wx.request({
                                        url: _this.globalData.antiqueBaseUrl+'/getOpenId.html',
                                        data: {
                                          code: res_login.code, 
                                        },
                                        method: 'POST',
                                        header: {
                                          'content-type': 'application /x-www-form-urlencoded'
                                        },
                                        success: function (res) {
                                          that.setData({
                                            nickName: res.data.nickName,
                                            avatarUrl: res.data.avatarUrl,

                                          })
                                          wx.setStorageSync('openid', res.data.openId);
                                        }
                                      })
                                    }
                                  })
                                }
                              }
                            });
                         }
                        }, fail: function (res) {
                           
                        }
                      })

                    }
                  }
                })
              }, complete: function (res) {


              }
            })
          }
        }
      })

    }
  */
  //////////////////////////////////////////////////////////
    // wx.login({
    //   success: function (res) {
    //     var code = res.code
    //     console.log(code);
    //     wx.setStorageSync('code', code)
    //     wx.request({
    //       url: _this.globalData.antiqueBaseUrl + '/getOpenId.html',
    //       method: 'POST',
    //       header: {
    //         'content-type': 'application/x-www-form-urlencoded'
    //       },
    //       data: {
    //         code: res.code
    //       },
    //       success: function (res) {
    //         wx.setStorageSync('openid', res.data);
    //         console.log("openid: ", res.data);
    //       }
    //     });
    //   }
    // });
    wx.getSetting({
      success: res => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          console.log('已经授权')
          // 已经授权，可以直接调用 getUserInfo 
          wx.getUserInfo({
            success: res => {
              console.log('app.js执行 getUserInfo')
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        } else {
          console.log('wiekjwdnjw')
          wx.getUserInfo({
            success: res => {
              console.log('app.js执行 getUserInfo2')
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            },
            fail: res=>{
               console.log('whjsbdwhjdbw')
            }
          })
        }
      }
    }) 
  
 
  },
  globalData: {
    imgs:[],
    userInfo: null,
    antiqueBaseUrl: "http://192.168.0.178:8080/",
    //antiqueBaseUrl: "https://www.wuhanzhuangxiu01.cn/curio/",
    antiqueImgUrl: "https://www.wuhanzhuangxiu01.cn/"
  }
})